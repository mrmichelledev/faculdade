#include <stdio.h>
#include <stdlib.h>
#include "conjuntos.h"

struct conjunto{
    int elementos[100];
    int tam;
};


int criaConjunto(Conjunto** c){
    *c = (Conjunto*)malloc(sizeof(Conjunto));
    if(*c != NULL){
        (*c)->tam = 0;
        printf("%d\n", (*c)->tam);
        return 1;
    }

    return 0;
}

int conjuntoVazio(Conjunto* c){
    printf("%d\n", c->tam);
    return c->tam == 0;
}

int insereElementoConjunto(int e, Conjunto* c){
    int i;

    if(c->tam >= 0){
        //verificando se o elemento já está inserido
        for(i = 0; i < c->tam; i++){
            if(c->elementos[i] == e)
                return 0;
        }
        printf("\nInserindo elementos: \n");
       // c->elementos = (int*) realloc(c->elementos, ((c->tam)+1)*sizeof(int));
        c->elementos[c->tam] = e;
        printf("tamanho: %d, Elemento: %d\n", c->tam, c->elementos[0]);

        c->tam++;
        return 1;
    }
    return 0;
}

int excluirElementoConjunto(int e, Conjunto* c){
    int i, aux = -1;
    for(i = 0; i < c->tam; i++){
        if(c->elementos[i] == e){
            aux = i;
            break;
        }
    }

    if(aux == -1) return 0;

    for(i = aux; i < c->tam-1; i++){
        c->elementos[i] = c->elementos[i+1];
    }

    //c->elementos = (int*) realloc(c->elementos, (c->tam-1)*sizeof(int));

    if(c->elementos != NULL) return 1;

    return 0;
}

int tamanhoConjunto(Conjunto* c){
    if(c->tam > 0) return c->tam;
    return 0;
}

void mostraConjunto(Conjunto* c){
    int i;
    printf("%d\n", c->tam);
    for(i = 0; i < c->tam; i++){
        printf("%d", c->elementos[i]);
        if(i != c->tam-1) printf(" ");
    }

    printf("\n");
}

/*int maior(int e, Conjunto* c){

}

int menor(int e, Conjunto* c){

}

int pertenceConjunto(int e, Conjunto* c){

}

int conjuntosIdenticos(Conjunto* c1, Conjunto* c2){

}

int subconjunto(Conjunto* c1, Conjunto* c2){

}*/