#include <stdio.h>
#include <stdlib.h>
#include "conjuntos.h"

int main(){
    Conjunto *c = NULL, **p;
    int elemento;
    p = &c;
    //criando o conjunto
    if(criaConjunto(p)) printf("SUCESSO\n");
    else printf("FALHA\n");

    //verifica se o conjunto esta vazio
    if (conjuntoVazio(c) == 1) printf("TRUE\n");
    else printf("FALSE\n");

    //inserindo elemento
    printf("Insira um numero inteiro para ser adicionado ao conjunto: \n");
    scanf("%d", &elemento);
    if (insereElementoConjunto(elemento, c) == 1) printf("SUCESSO\n");
    else printf("FALHA\n");

    printf("Mostrando o conjunto: ");
    mostraConjunto(c);

    //excluindo elementos
    printf("Insira um numero inteiro para ser excluido do conjunto: \n");
    scanf("%d", &elemento);
    if (excluirElementoConjunto(elemento, c) == 1) printf("SUCESSO\n");
    else printf("FALHA\n");

    printf("Mostrando o conjunto: ");
    mostraConjunto(c);

    //tamanho do conjunto
    printf("%d", tamanhoConjunto);

    return 0;
}
