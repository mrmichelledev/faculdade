typedef struct conjunto Conjunto;

int criaConjunto(Conjunto** c);
int conjuntoVazio(Conjunto* c);
int insereElementoConjunto(int e, Conjunto* c);
int excluirElementoConjunto(int e,Conjunto* c);
int tamanhoConjunto(Conjunto* c);
int maior(int e, Conjunto* c);
int menor(int e, Conjunto* c);
int pertenceConjunto(int e, Conjunto* c);
int conjuntosIdenticos(Conjunto* c1, Conjunto* c2);
int subconjunto(Conjunto* c1, Conjunto* c2);
void mostraConjunto(Conjunto* c);