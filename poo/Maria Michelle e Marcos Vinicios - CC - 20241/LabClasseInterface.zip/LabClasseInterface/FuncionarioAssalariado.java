package LabClasseInterface;

public interface FuncionarioAssalariado {
    void receberSalario(int nTurmas);
}
