package LabClasseInterface;

public interface Estudante {
    void estudar();
}
